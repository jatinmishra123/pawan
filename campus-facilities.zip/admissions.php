<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>Admissions - NiceSchool Bootstrap Template</title>
    <meta name="description" content="" />
    <meta name="keywords" content="" />

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon" />
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon" />

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com" rel="preconnect" />
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
      rel="stylesheet"
    />

    <!-- Vendor CSS Files -->
    <link
      href="assets/vendor/bootstrap/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
      href="assets/vendor/bootstrap-icons/bootstrap-icons.css"
      rel="stylesheet"
    />
    <link href="assets/vendor/aos/aos.css" rel="stylesheet" />
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet" />
    <link
      href="assets/vendor/glightbox/css/glightbox.min.css"
      rel="stylesheet"
    />

    <!-- Main CSS File -->
    <link href="assets/css/main.css" rel="stylesheet" />

    <!-- =======================================================
  * Template Name: NiceSchool
  * Template URL: https://bootstrapmade.com/nice-school-bootstrap-education-template/
  * Updated: May 10 2025 with Bootstrap v5.3.6
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  </head>

  <body class="admissions-page">
    <header id="header" class="header d-flex align-items-center fixed-top">
      <div
        class="container-fluid container-xl position-relative d-flex align-items-center justify-content-between"
      >
        <a href="index
" class="logo d-flex align-items-center">
          <!-- Uncomment the line below if you also wish to use an image logo -->
          <!-- <img src="assets/img/logo.webp" alt=""> -->
          <i class="bi bi-buildings"></i>
                              <img src="assets/img/logo.png.jpeg" alt="logo"> 

        </a>

        <nav id="navmenu" class="navmenu">
          <ul>
            <li><a href="index
">Home</a></li>
            <li class="dropdown">
              <a href="about
"
                ><span>About</span>
                <i class="bi bi-chevron-down toggle-dropdown"></i
              ></a>
              <ul>
                <li><a href="about
">About Us</a></li>
                <li><a href="admissions
" class="active">Admissions</a></li>
                <li><a href="academics
">Academics</a></li>
                <li><a href="faculty-staff
">Faculty &amp; Staff</a></li>
                <li>
                  <a href="campus-facilities
">Campus &amp; Facilities</a>
                </li>
              </ul>
            </li>

            <li><a href="students-life
">Students Life</a></li>
            <li><a href="news
">News</a></li>
            <li><a href="events
">Events</a></li>
            <li><a href="alumni
">Alumni</a></li>
            <li class="dropdown">
              <a href="#"
                ><span>More Pages</span>
                <i class="bi bi-chevron-down toggle-dropdown"></i
              ></a>
              <ul>
                <li><a href="news-details
">News Details</a></li>
                <li><a href="event-details
">Event Details</a></li>
                <li><a href="privacy
">Privacy</a></li>
                <li><a href="terms-of-service
">Terms of Service</a></li>
                <li><a href="404
">Error 404</a></li>
                <li><a href="starter-page
">Starter Page</a></li>
              </ul>
            </li>

            <li class="dropdown">
              <a href="#"
                ><span>Dropdown</span>
                <i class="bi bi-chevron-down toggle-dropdown"></i
              ></a>
              <ul>
                <li><a href="#">Dropdown 1</a></li>
                <li class="dropdown">
                  <a href="#"
                    ><span>Deep Dropdown</span>
                    <i class="bi bi-chevron-down toggle-dropdown"></i
                  ></a>
                  <ul>
                    <li><a href="#">Deep Dropdown 1</a></li>
                    <li><a href="#">Deep Dropdown 2</a></li>
                    <li><a href="#">Deep Dropdown 3</a></li>
                    <li><a href="#">Deep Dropdown 4</a></li>
                    <li><a href="#">Deep Dropdown 5</a></li>
                  </ul>
                </li>
                <li><a href="#">Dropdown 2</a></li>
                <li><a href="#">Dropdown 3</a></li>
                <li><a href="#">Dropdown 4</a></li>
              </ul>
            </li>
            <li><a href="contact
">Contact</a></li>
          </ul>
          <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>
      </div>
    </header>

    <main class="main">
      <!-- Page Title -->
      <div
        class="page-title dark-background"
        style="background-image: url(assets/img/education/showcase-1.webp)"
      >
        <div class="container position-relative">
          <h1>Admissions</h1>
          <p>
            Esse dolorum voluptatum ullam est sint nemo et est ipsa porro
            placeat quibusdam quia assumenda numquam molestias.
          </p>
          <nav class="breadcrumbs">
            <ol>
              <li><a href="index
">Home</a></li>
              <li class="current">Admissions</li>
            </ol>
          </nav>
        </div>
      </div>
      <!-- End Page Title -->

      <!-- Admissions Section -->
      <section id="admissions" class="admissions section">
        <div class="container" data-aos="fade-up" data-aos-delay="100">
          <div class="row gy-5 g-lg-5">
            <div class="col-lg-6">
              <div class="admissions-info" data-aos="fade-up">
                <h2>Begin Your Academic Journey Today</h2>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin
                  gravida nibh vel velit auctor aliquet. Aenean sollicitudin,
                  lorem quis bibendum auctor, nisi elit consequat ipsum, nec
                  sagittis sem nibh id elit. Duis sed odio sit amet.
                </p>

                <div class="admissions-steps mt-5">
                  <h3>How to Apply</h3>
                  <div class="steps-wrapper mt-4">
                    <div
                      class="step-item"
                      data-aos="fade-up"
                      data-aos-delay="100"
                    >
                      <div class="step-number">1</div>
                      <div class="step-content">
                        <h4>Submit Application</h4>
                        <p>
                          Mauris blandit aliquet elit, eget tincidunt nibh
                          pulvinar a. Sed porttitor lectus nibh. Praesent sapien
                          massa.
                        </p>
                      </div>
                    </div>

                    <div
                      class="step-item"
                      data-aos="fade-up"
                      data-aos-delay="200"
                    >
                      <div class="step-number">2</div>
                      <div class="step-content">
                        <h4>Send Documents</h4>
                        <p>
                          Vestibulum ante ipsum primis in faucibus orci luctus
                          et ultrices posuere cubilia Curae; Donec velit neque,
                          auctor sit amet aliquam vel.
                        </p>
                      </div>
                    </div>

                    <div
                      class="step-item"
                      data-aos="fade-up"
                      data-aos-delay="300"
                    >
                      <div class="step-number">3</div>
                      <div class="step-content">
                        <h4>Interview Process</h4>
                        <p>
                          Curabitur non nulla sit amet nisl tempus convallis
                          quis ac lectus. Nulla porttitor accumsan tincidunt.
                        </p>
                      </div>
                    </div>

                    <div
                      class="step-item"
                      data-aos="fade-up"
                      data-aos-delay="400"
                    >
                      <div class="step-number">4</div>
                      <div class="step-content">
                        <h4>Receive Decision</h4>
                        <p>
                          Vivamus suscipit tortor eget felis porttitor volutpat.
                          Cras ultricies ligula sed magna dictum porta. Nulla
                          quis lorem ut libero.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="deadlines mt-5" data-aos="fade-up">
                  <h3>Key Admission Deadlines</h3>
                  <div class="deadline-grid mt-4">
                    <div class="deadline-item">
                      <h4>Fall Semester</h4>
                      <div class="date">March 15, 2023</div>
                    </div>
                    <div class="deadline-item">
                      <h4>Spring Semester</h4>
                      <div class="date">October 1, 2023</div>
                    </div>
                    <div class="deadline-item">
                      <h4>Summer Session</h4>
                      <div class="date">January 30, 2024</div>
                    </div>
                    <div class="deadline-item">
                      <h4>Early Decision</h4>
                      <div class="date">November 15, 2023</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-6">
              <div class="admissions-requirements" data-aos="fade-up">
                <h3>Admission Requirements</h3>
                <div class="requirements-list mt-4">
                  <div
                    class="requirement-item"
                    data-aos="fade-up"
                    data-aos-delay="100"
                  >
                    <div class="icon-box">
                      <i class="bi bi-mortarboard-fill"></i>
                    </div>
                    <div>
                      <h4>Academic Records</h4>
                      <p>
                        Pellentesque in ipsum id orci porta dapibus. Vivamus
                        magna justo, lacinia eget consectetur sed.
                      </p>
                    </div>
                  </div>

                  <div
                    class="requirement-item"
                    data-aos="fade-up"
                    data-aos-delay="200"
                  >
                    <div class="icon-box">
                      <i class="bi bi-file-earmark-text"></i>
                    </div>
                    <div>
                      <h4>Recommendation Letters</h4>
                      <p>
                        Nulla quis lorem ut libero malesuada feugiat. Curabitur
                        non nulla sit amet nisl tempus.
                      </p>
                    </div>
                  </div>

                  <div
                    class="requirement-item"
                    data-aos="fade-up"
                    data-aos-delay="300"
                  >
                    <div class="icon-box">
                      <i class="bi bi-journal-richtext"></i>
                    </div>
                    <div>
                      <h4>Personal Statement</h4>
                      <p>
                        Proin eget tortor risus. Vivamus suscipit tortor eget
                        felis porttitor volutpat.
                      </p>
                    </div>
                  </div>

                  <div
                    class="requirement-item"
                    data-aos="fade-up"
                    data-aos-delay="400"
                  >
                    <div class="icon-box">
                      <i class="bi bi-graph-up"></i>
                    </div>
                    <div>
                      <h4>Standardized Tests</h4>
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        Mauris blandit aliquet elit.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div class="request-info mt-5" data-aos="fade-up">
                <div class="card">
                  <div class="card-body">
                    <h3 class="card-title">Request Information</h3>
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Proin gravida nibh vel velit auctor aliquet.
                    </p>

                    <form
                      class="php-email-form mt-4"
                      action="forms/contact
"
                    >
                      <div class="mb-3">
                        <input
                          type="text"
                          name="name"
                          class="form-control"
                          placeholder="Full Name"
                          required=""
                        />
                      </div>
                      <div class="mb-3">
                        <input
                          type="email"
                          name="email"
                          class="form-control"
                          placeholder="Email Address"
                          required=""
                        />
                      </div>
                      <div class="mb-3">
                        <input
                          type="tel"
                          name="phone"
                          class="form-control"
                          placeholder="Phone Number"
                        />
                      </div>
                      <div class="mb-3">
                        <select name="subject" class="form-select" required="">
                          <option value="" selected="" disabled="">
                            Program of Interest
                          </option>
                          <option value="Undergraduate">Undergraduate</option>
                          <option value="Graduate">Graduate</option>
                          <option value="Doctoral">Doctoral</option>
                          <option value="Certificate">Certificate</option>
                        </select>
                      </div>
                      <div class="mb-3">
                        <textarea
                          name="message"
                          class="form-control"
                          rows="3"
                          placeholder="Questions or Comments"
                          required=""
                        ></textarea>
                      </div>
                      <div class="loading">Loading</div>
                      <div class="error-message"></div>
                      <div class="sent-message">
                        Your request has been sent. Thank you!
                      </div>
                      <div class="text-center">
                        <button type="submit" class="btn btn-primary">
                          Submit Request
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="cta-wrapper mt-5" data-aos="fade-up">
            <div class="row g-0">
              <div class="col-md-6">
                <div class="cta-item tour">
                  <i class="bi bi-building"></i>
                  <h3>Visit Our Campus</h3>
                  <p>
                    Nulla porttitor accumsan tincidunt. Vivamus suscipit tortor
                    eget felis porttitor volutpat.
                  </p>
                  <a href="#" class="btn btn-secondary">Schedule a Tour</a>
                </div>
              </div>
              <div class="col-md-6">
                <div class="cta-item apply">
                  <i class="bi bi-file-earmark-check"></i>
                  <h3>Ready to Apply?</h3>
                  <p>
                    Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a.
                    Curabitur non nulla sit amet.
                  </p>
                  <a href="#" class="btn btn-primary">Start Application</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /Admissions Section -->
    </main>

    <footer id="footer" class="footer position-relative dark-background">
      <div class="container footer-top">
        <div class="row gy-4">
          <div class="col-lg-4 col-md-6 footer-about">
            <a href="index
" class="logo d-flex align-items-center">
              <span class="sitename">NiceSchool</span>
            </a>
            <div class="footer-contact pt-3">
              <p>A108 Adam Street</p>
              <p>New York, NY 535022</p>
              <p class="mt-3">
                <strong>Phone:</strong> <span>+1 5589 55488 55</span>
              </p>
              <p><strong>Email:</strong> <span>info@example.com</span></p>
            </div>
            <div class="social-links d-flex mt-4">
              <a href=""><i class="bi bi-twitter-x"></i></a>
              <a href=""><i class="bi bi-facebook"></i></a>
              <a href=""><i class="bi bi-instagram"></i></a>
              <a href=""><i class="bi bi-linkedin"></i></a>
            </div>
          </div>

          <div class="col-lg-2 col-md-3 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><a href="#">Home</a></li>
              <li><a href="#">About us</a></li>
              <li><a href="#">Services</a></li>
              <li><a href="#">Terms of service</a></li>
              <li><a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-2 col-md-3 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><a href="#">Web Design</a></li>
              <li><a href="#">Web Development</a></li>
              <li><a href="#">Product Management</a></li>
              <li><a href="#">Marketing</a></li>
              <li><a href="#">Graphic Design</a></li>
            </ul>
          </div>

          <div class="col-lg-2 col-md-3 footer-links">
            <h4>Hic solutasetp</h4>
            <ul>
              <li><a href="#">Molestiae accusamus iure</a></li>
              <li><a href="#">Excepturi dignissimos</a></li>
              <li><a href="#">Suscipit distinctio</a></li>
              <li><a href="#">Dilecta</a></li>
              <li><a href="#">Sit quas consectetur</a></li>
            </ul>
          </div>

          <div class="col-lg-2 col-md-3 footer-links">
            <h4>Nobis illum</h4>
            <ul>
              <li><a href="#">Ipsam</a></li>
              <li><a href="#">Laudantium dolorum</a></li>
              <li><a href="#">Dinera</a></li>
              <li><a href="#">Trodelas</a></li>
              <li><a href="#">Flexo</a></li>
            </ul>
          </div>
        </div>
      </div>

      <div class="container copyright text-center mt-4">
        <p>
          © <span>Copyright</span>
          <strong class="px-1 sitename">MyWebsite</strong>
          <span>All Rights Reserved</span>
        </p>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you've purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: [buy-url] -->
          Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
        </div>
      </div>
    </footer>

    <!-- Scroll Top -->
    <a
      href="#"
      id="scroll-top"
      class="scroll-top d-flex align-items-center justify-content-center"
      ><i class="bi bi-arrow-up-short"></i
    ></a>

    <!-- Preloader -->
    <div id="preloader"></div>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
    <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>

    <!-- Main JS File -->
    <script src="assets/js/main.js"></script>
  </body>
</html>
