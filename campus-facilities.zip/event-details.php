<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>Event Details - NiceSchool Bootstrap Template</title>
    <meta name="description" content="" />
    <meta name="keywords" content="" />

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon" />
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon" />

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com" rel="preconnect" />
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
      rel="stylesheet"
    />

    <!-- Vendor CSS Files -->
    <link
      href="assets/vendor/bootstrap/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
      href="assets/vendor/bootstrap-icons/bootstrap-icons.css"
      rel="stylesheet"
    />
    <link href="assets/vendor/aos/aos.css" rel="stylesheet" />
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet" />
    <link
      href="assets/vendor/glightbox/css/glightbox.min.css"
      rel="stylesheet"
    />

    <!-- Main CSS File -->
    <link href="assets/css/main.css" rel="stylesheet" />

    <!-- =======================================================
  * Template Name: NiceSchool
  * Template URL: https://bootstrapmade.com/nice-school-bootstrap-education-template/
  * Updated: May 10 2025 with Bootstrap v5.3.6
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  </head>

  <body class="event-details-page">
    <header id="header" class="header d-flex align-items-center fixed-top">
      <div
        class="container-fluid container-xl position-relative d-flex align-items-center justify-content-between"
      >
        <a href="index
" class="logo d-flex align-items-center">
          <!-- Uncomment the line below if you also wish to use an image logo -->
          <!-- <img src="assets/img/logo.webp" alt=""> -->
          <i class="bi bi-buildings"></i>
                              <img src="assets/img/logo.png.jpeg" alt="logo"> 

        </a>

        <nav id="navmenu" class="navmenu">
          <ul>
            <li><a href="index
">Home</a></li>
            <li class="dropdown">
              <a href="about
"
                ><span>About</span>
                <i class="bi bi-chevron-down toggle-dropdown"></i
              ></a>
              <ul>
                <li><a href="about
">About Us</a></li>
                <li><a href="admissions
">Admissions</a></li>
                <li><a href="academics
">Academics</a></li>
                <li><a href="faculty-staff
">Faculty &amp; Staff</a></li>
                <li>
                  <a href="campus-facilities
">Campus &amp; Facilities</a>
                </li>
              </ul>
            </li>

            <li><a href="students-life
">Students Life</a></li>
            <li><a href="news
">News</a></li>
            <li><a href="events
">Events</a></li>
            <li><a href="alumni
">Alumni</a></li>
            <li class="dropdown">
              <a href="#"
                ><span>More Pages</span>
                <i class="bi bi-chevron-down toggle-dropdown"></i
              ></a>
              <ul>
                <li><a href="news-details
">News Details</a></li>
                <li>
                  <a href="event-details
" class="active">Event Details</a>
                </li>
                <li><a href="privacy
">Privacy</a></li>
                <li><a href="terms-of-service
">Terms of Service</a></li>
                <li><a href="404
">Error 404</a></li>
                <li><a href="starter-page
">Starter Page</a></li>
              </ul>
            </li>

            <li class="dropdown">
              <a href="#"
                ><span>Dropdown</span>
                <i class="bi bi-chevron-down toggle-dropdown"></i
              ></a>
              <ul>
                <li><a href="#">Dropdown 1</a></li>
                <li class="dropdown">
                  <a href="#"
                    ><span>Deep Dropdown</span>
                    <i class="bi bi-chevron-down toggle-dropdown"></i
                  ></a>
                  <ul>
                    <li><a href="#">Deep Dropdown 1</a></li>
                    <li><a href="#">Deep Dropdown 2</a></li>
                    <li><a href="#">Deep Dropdown 3</a></li>
                    <li><a href="#">Deep Dropdown 4</a></li>
                    <li><a href="#">Deep Dropdown 5</a></li>
                  </ul>
                </li>
                <li><a href="#">Dropdown 2</a></li>
                <li><a href="#">Dropdown 3</a></li>
                <li><a href="#">Dropdown 4</a></li>
              </ul>
            </li>
            <li><a href="contact
">Contact</a></li>
          </ul>
          <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>
      </div>
    </header>

    <main class="main">
      <!-- Page Title -->
      <div
        class="page-title dark-background"
        style="background-image: url(assets/img/education/showcase-1.webp)"
      >
        <div class="container position-relative">
          <h1>Event Details</h1>
          <p>
            Esse dolorum voluptatum ullam est sint nemo et est ipsa porro
            placeat quibusdam quia assumenda numquam molestias.
          </p>
          <nav class="breadcrumbs">
            <ol>
              <li><a href="index
">Home</a></li>
              <li class="current">Event Details</li>
            </ol>
          </nav>
        </div>
      </div>
      <!-- End Page Title -->

      <!-- Event Section -->
      <section id="event" class="event section">
        <div class="container" data-aos="fade-up" data-aos-delay="100">
          <div class="row">
            <div class="col-lg-8">
              <div class="event-image mb-4" data-aos="fade-up">
                <img
                  src="assets/img/education/events-9.webp"
                  alt="Event"
                  class="img-fluid rounded"
                />
              </div>

              <div
                class="event-meta mb-4"
                data-aos="fade-up"
                data-aos-delay="100"
              >
                <div class="row g-3">
                  <div class="col-md-4">
                    <div class="meta-item">
                      <i class="bi bi-calendar-date"></i>
                      <span>10/24/2023</span>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="meta-item">
                      <i class="bi bi-clock"></i>
                      <span>3:00 PM - 6:00 PM</span>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="meta-item">
                      <i class="bi bi-geo-alt"></i>
                      <span>Main Auditorium</span>
                    </div>
                  </div>
                </div>
              </div>

              <div
                class="event-content"
                data-aos="fade-up"
                data-aos-delay="200"
              >
                <h2>Annual Science Exhibition</h2>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Aliquam non mauris maximus, finibus dui eget, rhoncus diam.
                  Suspendisse blandit diam at nisi rutrum, non blandit magna
                  molestie. Cras dapibus finibus diam, eu varius purus eleifend
                  eu. Nulla facilisi. Vestibulum ante ipsum primis in faucibus
                  orci luctus et ultrices posuere cubilia curae.
                </p>
                <p>
                  Donec cursus, sapien vel convallis lobortis, dolor nisl
                  pharetra est, ac facilisis ligula sapien vel justo. Curabitur
                  sed semper risus, non tempus lorem. Nulla sodales feugiat
                  tempus. Cras tincidunt dapibus ante, ut rutrum sapien finibus
                  at. Mauris consequat tellus eu nunc pharetra, eu convallis
                  elit tempor.
                </p>

                <h3 class="mt-4">Event Highlights</h3>
                <ul class="event-highlights">
                  <li>
                    <i class="bi bi-check-circle"></i>
                    <span
                      >Interactive student presentations of scientific
                      experiments</span
                    >
                  </li>
                  <li>
                    <i class="bi bi-check-circle"></i>
                    <span
                      >Special lecture by renowned physicist Dr. Robert
                      Jenkins</span
                    >
                  </li>
                  <li>
                    <i class="bi bi-check-circle"></i>
                    <span
                      >Robotics competition with prizes for top three
                      teams</span
                    >
                  </li>
                  <li>
                    <i class="bi bi-check-circle"></i>
                    <span>Science demonstrations by faculty members</span>
                  </li>
                  <li>
                    <i class="bi bi-check-circle"></i>
                    <span>Exhibition of innovative student projects</span>
                  </li>
                </ul>

                <h3 class="mt-4">Event Schedule</h3>
                <div class="schedule-table">
                  <div class="schedule-row">
                    <div class="schedule-time">3:00 PM - 3:30 PM</div>
                    <div class="schedule-activity">
                      <h4>Opening Ceremony</h4>
                      <p>
                        Welcome address by Principal and introduction to the
                        event
                      </p>
                    </div>
                  </div>
                  <div class="schedule-row">
                    <div class="schedule-time">3:30 PM - 4:30 PM</div>
                    <div class="schedule-activity">
                      <h4>Student Project Presentations</h4>
                      <p>
                        Selected students showcase their scientific innovations
                      </p>
                    </div>
                  </div>
                  <div class="schedule-row">
                    <div class="schedule-time">4:30 PM - 5:15 PM</div>
                    <div class="schedule-activity">
                      <h4>Guest Lecture</h4>
                      <p>
                        Special lecture on "Future of Quantum Computing" by Dr.
                        Robert Jenkins
                      </p>
                    </div>
                  </div>
                  <div class="schedule-row">
                    <div class="schedule-time">5:15 PM - 5:45 PM</div>
                    <div class="schedule-activity">
                      <h4>Robotics Demonstration</h4>
                      <p>
                        Live demonstration of student-built robots and
                        automation projects
                      </p>
                    </div>
                  </div>
                  <div class="schedule-row">
                    <div class="schedule-time">5:45 PM - 6:00 PM</div>
                    <div class="schedule-activity">
                      <h4>Award Ceremony &amp; Closing</h4>
                      <p>
                        Distribution of certificates and recognition of
                        outstanding projects
                      </p>
                    </div>
                  </div>
                </div>

                <div
                  class="event-gallery mt-5"
                  data-aos="fade-up"
                  data-aos-delay="300"
                >
                  <h3>Event Gallery</h3>
                  <p>Images from previous year's science exhibition:</p>
                  <div class="row g-4 mt-2">
                    <div class="col-md-4">
                      <a
                        href="assets/img/education/events-1.webp"
                        class="glightbox"
                      >
                        <img
                          src="assets/img/education/events-1.webp"
                          alt="Event Gallery"
                          class="img-fluid rounded"
                        />
                      </a>
                    </div>
                    <div class="col-md-4">
                      <a
                        href="assets/img/education/events-2.webp"
                        class="glightbox"
                      >
                        <img
                          src="assets/img/education/events-2.webp"
                          alt="Event Gallery"
                          class="img-fluid rounded"
                        />
                      </a>
                    </div>
                    <div class="col-md-4">
                      <a
                        href="assets/img/education/events-3.webp"
                        class="glightbox"
                      >
                        <img
                          src="assets/img/education/events-3.webp"
                          alt="Event Gallery"
                          class="img-fluid rounded"
                        />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-4">
              <div class="event-sidebar">
                <div
                  class="sidebar-widget registration-form"
                  data-aos="fade-left"
                  data-aos-delay="200"
                >
                  <h3>Register for this Event</h3>
                  <form>
                    <div class="mb-3">
                      <label for="name" class="form-label">Full Name</label>
                      <input
                        type="text"
                        class="form-control"
                        id="name"
                        required=""
                      />
                    </div>
                    <div class="mb-3">
                      <label for="email" class="form-label"
                        >Email Address</label
                      >
                      <input
                        type="email"
                        class="form-control"
                        id="email"
                        required=""
                      />
                    </div>
                    <div class="mb-3">
                      <label for="phone" class="form-label">Phone Number</label>
                      <input type="tel" class="form-control" id="phone" />
                    </div>
                    <div class="mb-3">
                      <label for="student-type" class="form-label"
                        >You are a</label
                      >
                      <select class="form-select" id="student-type">
                        <option selected="">Select an option</option>
                        <option value="student">Student</option>
                        <option value="parent">Parent</option>
                        <option value="teacher">Teacher</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    <div class="d-grid">
                      <button type="submit" class="btn btn-register">
                        Register Now
                      </button>
                    </div>
                  </form>
                </div>

                <div
                  class="sidebar-widget organizer-info"
                  data-aos="fade-left"
                  data-aos-delay="300"
                >
                  <h3>Event Organizer</h3>
                  <div class="organizer-details">
                    <div class="organizer-image">
                      <img
                        src="assets/img/person/person-m-5.webp"
                        class="img-fluid rounded"
                        alt="Organizer"
                      />
                    </div>
                    <div class="organizer-content">
                      <h4>Prof. Michael Anderson</h4>
                      <p class="organizer-position">
                        Head of Science Department
                      </p>
                      <p>For queries related to the event, please contact:</p>
                      <div class="organizer-contact">
                        <p>
                          <i class="bi bi-envelope"></i> michael@example.com
                        </p>
                        <p><i class="bi bi-telephone"></i> +1 (555) 123-4567</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div
                  class="sidebar-widget related-events"
                  data-aos="fade-left"
                  data-aos-delay="400"
                >
                  <h3>Related Events</h3>
                  <div class="related-event-item">
                    <div class="related-event-date">
                      <span class="day">15</span>
                      <span class="month">Nov</span>
                    </div>
                    <div class="related-event-info">
                      <h4>Mathematics Olympiad</h4>
                      <p><i class="bi bi-geo-alt"></i> Room 203, East Wing</p>
                    </div>
                  </div>
                  <div class="related-event-item">
                    <div class="related-event-date">
                      <span class="day">05</span>
                      <span class="month">Dec</span>
                    </div>
                    <div class="related-event-info">
                      <h4>Literature Festival</h4>
                      <p><i class="bi bi-geo-alt"></i> Central Library</p>
                    </div>
                  </div>
                  <div class="related-event-item">
                    <div class="related-event-date">
                      <span class="day">18</span>
                      <span class="month">Dec</span>
                    </div>
                    <div class="related-event-info">
                      <h4>Annual Sports Meet</h4>
                      <p><i class="bi bi-geo-alt"></i> School Ground</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /Event Section -->
    </main>

    <footer id="footer" class="footer position-relative dark-background">
      <div class="container footer-top">
        <div class="row gy-4">
          <div class="col-lg-4 col-md-6 footer-about">
            <a href="index
" class="logo d-flex align-items-center">
              <span class="sitename">NiceSchool</span>
            </a>
            <div class="footer-contact pt-3">
              <p>A108 Adam Street</p>
              <p>New York, NY 535022</p>
              <p class="mt-3">
                <strong>Phone:</strong> <span>+1 5589 55488 55</span>
              </p>
              <p><strong>Email:</strong> <span>info@example.com</span></p>
            </div>
            <div class="social-links d-flex mt-4">
              <a href=""><i class="bi bi-twitter-x"></i></a>
              <a href=""><i class="bi bi-facebook"></i></a>
              <a href=""><i class="bi bi-instagram"></i></a>
              <a href=""><i class="bi bi-linkedin"></i></a>
            </div>
          </div>

          <div class="col-lg-2 col-md-3 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><a href="#">Home</a></li>
              <li><a href="#">About us</a></li>
              <li><a href="#">Services</a></li>
              <li><a href="#">Terms of service</a></li>
              <li><a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-2 col-md-3 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><a href="#">Web Design</a></li>
              <li><a href="#">Web Development</a></li>
              <li><a href="#">Product Management</a></li>
              <li><a href="#">Marketing</a></li>
              <li><a href="#">Graphic Design</a></li>
            </ul>
          </div>

          <div class="col-lg-2 col-md-3 footer-links">
            <h4>Hic solutasetp</h4>
            <ul>
              <li><a href="#">Molestiae accusamus iure</a></li>
              <li><a href="#">Excepturi dignissimos</a></li>
              <li><a href="#">Suscipit distinctio</a></li>
              <li><a href="#">Dilecta</a></li>
              <li><a href="#">Sit quas consectetur</a></li>
            </ul>
          </div>

          <div class="col-lg-2 col-md-3 footer-links">
            <h4>Nobis illum</h4>
            <ul>
              <li><a href="#">Ipsam</a></li>
              <li><a href="#">Laudantium dolorum</a></li>
              <li><a href="#">Dinera</a></li>
              <li><a href="#">Trodelas</a></li>
              <li><a href="#">Flexo</a></li>
            </ul>
          </div>
        </div>
      </div>

      <div class="container copyright text-center mt-4">
        <p>
          © <span>Copyright</span>
          <strong class="px-1 sitename">MyWebsite</strong>
          <span>All Rights Reserved</span>
        </p>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you've purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: [buy-url] -->
          Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
        </div>
      </div>
    </footer>

    <!-- Scroll Top -->
    <a
      href="#"
      id="scroll-top"
      class="scroll-top d-flex align-items-center justify-content-center"
      ><i class="bi bi-arrow-up-short"></i
    ></a>

    <!-- Preloader -->
    <div id="preloader"></div>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
    <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>

    <!-- Main JS File -->
    <script src="assets/js/main.js"></script>
  </body>
</html>
